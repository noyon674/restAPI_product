//import file
const express = require('express');
const app = express();
const Router = require('./Router/userRoute');

//middleware
app.use(express.json());
app.use(express.urlencoded({extended: true}));

//dataBase connection with the server
require('./Config/dbConnection');


//Manage all routes
app.use('/api', Router);

//Home 
app.get('/', (req, res)=>{
    res.sendFile(__dirname + "/View/index.html");
})

////Error handling
//client site
app.use((req, res, next)=>{
    res.status(404).json({Message: 'Router is not found'});
    next();
});

//server site
app.use((err, req, res, next)=>{
    res.status(505).json({Message: 'Server is broken.'});
    console.log(err.Message)
});

//export 
module.exports = app;