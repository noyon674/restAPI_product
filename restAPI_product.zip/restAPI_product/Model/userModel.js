//import files
const Mongoose = require('mongoose');

//create schema
const productSchema = Mongoose.Schema({
    id: {
        type: String,
        reuire: true
    },
    productName:{
        type: String,
        reuire: true
    },
    productQuantity:{
        type: Number,
        reuire: true
    },
    productDetails:{
        type: String,
        reuire: true
    },
    createdOn:{
        type: Date,
        default: Date.now
    }
    
});

module.exports = Mongoose.model('Product', productSchema);