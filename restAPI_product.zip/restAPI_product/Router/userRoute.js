///import files
const userRoute = require('express').Router();
const {getAllProduct, getOneProduct, createProduct, updateProduct, deleteProduct} = require('../Controller/userController');

//get all product
userRoute.get('/product', getAllProduct);

//get one product by id
userRoute.get('/product/:id', getOneProduct);

//create product
userRoute.post('/product', createProduct);

//update product
userRoute.patch('/product/:id', updateProduct);

//delete product
userRoute.delete('/product/:id', deleteProduct);

//export 
module.exports = userRoute;