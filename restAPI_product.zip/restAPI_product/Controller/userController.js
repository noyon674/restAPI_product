//import file
const Product = require('../Model/userModel');
const {v4: uuidv4} = require('uuid');

//All routes controller
//get all product
const getAllProduct = async(req, res)=>{
    try {
        const allProducts = await Product.find();
        res.status(200).json(allProducts);
    } catch (error) {
        res.status(500).json(error.message);
    }
};

//get one product by id
const getOneProduct = async(req, res)=>{
    try {
        const oneProduct = await Product.findOne({id: req.params.id});
        res.status(200).json(oneProduct);
    } catch (error) {
        res.status(500).json(error.message);
    }
};

//create product
const createProduct = async(req, res)=>{
    try {
        const newProduct = new Product({
            id: uuidv4(),
            productName: req.body.pName,
            productQuantity: req.body.pQuantity,
            productDetails: req.body.pDetails
        });
        await newProduct.save();
        res.status(201).json(newProduct);
    } catch (error) {
        res.status(500).json(error.message);
    }
};

//product updated
const updateProduct = async(req, res)=>{
    try {
        const catchProduct = await Product.findOne({id: req.params.id});
        catchProduct.productQuantity = req.body.pQuantity;
        await catchProduct.save();
        res.status(200).json('Product information is updated.')
    } catch (error) {
        res.status(500).json(error.message);
    }
}

//product deleted
const deleteProduct = async(req, res)=>{
    try {
        await Product.deleteOne({id: req.params.id});
        res.status(200).json('Product is deleted.')
    } catch (error) {
        res.status(500).json(error.message);
    }
}
//export
module.exports = {getAllProduct, getOneProduct, createProduct, updateProduct, deleteProduct};