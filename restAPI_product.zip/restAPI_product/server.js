//import files
const App = require('./app');
const config = require('./Config/secrete');

//
const port = config.app.port;

//server run
App.listen(port, ()=>{
    console.log(`server running at http://localhost:${port}`);
});