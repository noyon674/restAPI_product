const Mongoose = require('mongoose');
const config = require('../Config/secrete');

//dataBase url
const DBURL = config.DBLink.url;

//connection
Mongoose.connect(DBURL)
.then(()=>{
    console.log('DataBase connecting properly.');
})
.catch((err)=>{
    console.log(err.message);
    process.exit(1);
})
